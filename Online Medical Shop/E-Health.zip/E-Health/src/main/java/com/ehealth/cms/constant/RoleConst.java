package com.ehealth.cms.constant;

public interface RoleConst {
	public static final String ADMIN_ROLE = "admin";
	public static final String USER_ROLE = "user";

}
